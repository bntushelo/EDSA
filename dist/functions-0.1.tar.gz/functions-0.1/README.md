# functions
This library was created to calculate metrics using eskom data.

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git@github.com:JonrePii/EDSA.git`

## updating this package from GitHub
`pip install --upgrade git@github.com:JonrePii/EDSA.git`